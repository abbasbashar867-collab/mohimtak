import type { MetadataRoute } from "next";
import { appUrl } from "@/lib/env";
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/api", "/setup", "/client", "/company", "/account"] }], sitemap: `${appUrl()}/sitemap.xml` };
}
